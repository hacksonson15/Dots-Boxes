# ⚡ Quick Setup Guide - 5 منٹ میں شروع کریں

## Step 1: Appwrite Account بنائیں (2 منٹ)

1. https://appwrite.io پر جائیں
2. "Start for Free" پر کلک کریں
3. Account بنائیں (email/password)
4. Login کریں
5. Console کھل جائے گا

## Step 2: Project بنائیں (1 منٹ)

1. "Create Project" بٹن دبائیں
2. Project name: `DotsAndBoxes` (یا اپنا نام)
3. Create کریں
4. Project ID نوٹ کریں (بعد میں چاہیے)

## Step 3: Database بنائیں (1 منٹ)

1. بائیں طرف "Databases" پر کلک کریں
2. "+ Create Database" بٹن دبائیں
3. نام: `GameDB` (یا اپنا نام)
4. Create کریں
5. Database ID نوٹ کریں

## Step 4: Collections بنائیں (1 منٹ)

### Collection 1: Users

1. "+ Create Collection" بٹن دبائیں
2. نام: `users`
3. Create کریں
4. اندر جائیں، "+ Create Attribute" دبائیں
5. یہ attributes add کریں:
   - `username` (String, Required ✓)
   - `createdAt` (DateTime)
   - `lastActive` (DateTime)
6. Collection ID نوٹ کریں

### Collection 2: Games

1. "+ Create Collection" بٹن دبائیں
2. نام: `games`
3. یہ attributes add کریں:
   - `player1` (String)
   - `player2` (String)
   - `p1Score` (Integer)
   - `p2Score` (Integer)
   - `turn` (Integer)
   - `status` (String)
   - `createdAt` (DateTime)
   - `createdBy` (String)
4. Collection ID نوٹ کریں

### Collection 3: Messages

1. "+ Create Collection" بٹن دبائیں
2. نام: `messages`
3. یہ attributes add کریں:
   - `sender` (String, Required ✓)
   - `text` (String, Required ✓)
   - `createdAt` (DateTime)
   - `isEdited` (Boolean)
   - `replyTo` (String)
4. Collection ID نوٹ کریں

## Step 5: IDs کو Config میں ڈالیں (1 منٹ)

File کھولیں: `appwrite_config.js`

ان lines کو تبدیل کریں (تمہاری values سے):

```javascript
const APPWRITE_ENDPOINT = "https://fra.cloud.appwrite.io/v1";
const APPWRITE_PROJECT_ID = "YOUR_PROJECT_ID_HERE";
const DATABASE_ID = "YOUR_DATABASE_ID_HERE";
const COLLECTION_USERS = "YOUR_USERS_COLLECTION_ID";
const COLLECTION_GAMES = "YOUR_GAMES_COLLECTION_ID";
const COLLECTION_MESSAGES = "YOUR_MESSAGES_COLLECTION_ID";
```

Appwrite console سے:
- **PROJECT_ID**: Settings → API Keys → Project ID
- **DATABASE_ID**: Database کے نام کے ساتھ
- **COLLECTION_IDs**: ہر collection کی details میں

## Step 6: Server چلائیں

### Windows/Mac/Linux

```bash
# Python 2.x
python -m SimpleHTTPServer 8000

# Python 3.x
python3 -m http.server 8000

# یا Node.js
npx http-server
```

Terminal میں یہ نظر آئے گا:
```
Serving HTTP on 0.0.0.0 port 8000 ...
```

## Step 7: App کھولیں! 🎉

Browser میں یہاں جائیں:

```
http://localhost:8000/login.html
```

یا single-page version:

```
http://localhost:8000/index.html
```

## ✅ کامیابی کی علامات

- [ ] Login page لوڈ ہو
- [ ] Username ڈال کر login ہو سکیں
- [ ] Game page آئے
- [ ] Chat page کام کرے
- [ ] Emojis اور GIFs load ہوں

## 🐛 اگر کچھ کام نہ کرے

### Login نہیں ہو رہی
```
error: "Failed to create user"
↓
appwrite_config.js میں Database ID اور Collection ID check کریں
```

### Chat messages نہیں آ رہے
```
error: "Could not load messages"
↓
messages collection ID غلط ہے
↓
Collection attributes check کریں (sender, text required)
```

### Appwrite endpoint error
```
error: "Cannot connect"
↓
APPWRITE_ENDPOINT check کریں
↓
Browser console میں exact error دیکھیں (F12)
```

## 💡 Pro Tips

1. **Browser Console کھولیں**: F12 دبائیں
   - Errors اور network calls دیکھیں
   - Debugging میں مدد ملے

2. **LocalStorage clear کریں**:
   ```javascript
   localStorage.clear()
   ```
   اگر login issue ہو

3. **Appwrite Logs چیکیں**:
   - Appwrite console → Logs
   - Recent errors دیکھیں

4. **CORS issues**:
   - اگر cross-origin error آئے
   - Appwrite dashboard میں CORS enable کریں

## 📱 Multi-Device Testing

```
Desktop:  http://localhost:8000/login.html
Phone:    http://[YOUR_IP]:8000/login.html
```

`YOUR_IP` = `ipconfig` (Windows) یا `ifconfig` (Mac/Linux) سے

## 🚀 Production کے لیے

1. **SSL/HTTPS setup** کریں
2. **Domain name** لگائیں
3. **Appwrite endpoint** update کریں (اگر self-hosted ہے)
4. **Environment variables** استعمال کریں
5. **Security rules** Appwrite میں سیٹ کریں

## 📞 Common IDs کہاں ملیں

### Appwrite Console میں

1. **PROJECT_ID**:
   - Settings (bottom left)
   - API Keys section
   - Project ID copy کریں

2. **ENDPOINT**:
   - Settings
   - API Key section میں URL
   - Format: `https://[region].appwrite.io/v1`

3. **DATABASE_ID**:
   - Databases سیکشن
   - اپنا database کھولیں
   - ID نیچے دائیں کونے میں

4. **COLLECTION_IDs**:
   - Database کے اندر
   - ہر collection کھولیں
   - ID copy کریں

## ✨ الگ الگ Files استعمال کریں

تین طریقے سے app چلا سکتے ہو:

```
1. Single Page:   /index.html
   ایک ہی page، سریع، کوئی reload نہیں

2. Multi Page:    /login.html → /game.html → /chat.html
   الگ pages، modern feel

3. Direct Links:
   - http://localhost:8000/game.html (direct login)
   - http://localhost:8000/chat.html (direct chat)
```

## 🎓 اگلے Steps

1. ✅ **Basic setup مکمل**
2. → Styling customize کریں (`styles.css`)
3. → Game rules شامل کریں (`game_logic.js`)
4. → Custom emojis add کریں (`chat_functions.js`)
5. → Production deployment کریں

---

**اب آپ تیار ہیں! Happy gaming! 🎮**
