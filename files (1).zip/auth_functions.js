// ============ AUTHENTICATION FUNCTIONS ============

async function handleLogin() {
  const els = getGameElements();
  const usernameInput = els.usernameInput;
  
  if (!usernameInput) return;
  
  const username = usernameInput.value.trim();
  if (!username) {
    alert("Please enter your username");
    return;
  }
  
  if (username.length < 3) {
    alert("Username must be at least 3 characters");
    return;
  }
  
  try {
    // Check if user exists
    let userId = null;
    try {
      const results = await databases.listDocuments(
        DATABASE_ID,
        COLLECTION_USERS,
        [Query.equal('username', username)]
      );
      
      if (results.documents.length > 0) {
        userId = results.documents[0].$id;
      }
    } catch (err) {
      console.log("User not found, creating new...");
    }
    
    // Create user if doesn't exist
    if (!userId) {
      const newUser = await databases.createDocument(
        DATABASE_ID,
        COLLECTION_USERS,
        ID.unique(),
        {
          username: username,
          createdAt: new Date().toISOString(),
          lastActive: new Date().toISOString()
        }
      );
      userId = newUser.$id;
    }
    
    // Set logged-in user
    loggedInUser = username;
    loggedInUserId = userId;
    
    // Save to localStorage
    localStorage.setItem('loggedInUser', username);
    localStorage.setItem('loggedInUserId', userId);
    
    // Show game setup page
    usernameInput.value = '';
    showPage('setup-game-page');
  } catch (error) {
    console.error('Login error:', error);
    alert('Login failed. Make sure Appwrite is connected.');
  }
}

async function setupTwoPlayerGame() {
  const els = getGameElements();
  const player1Input = els.player1Input;
  const player2Input = els.player2Input;
  
  if (!player1Input || !player2Input) return;
  
  const p1 = player1Input.value.trim();
  const p2 = player2Input.value.trim();
  
  if (!p1 || !p2) {
    alert("Enter both player names");
    return;
  }
  
  if (p1 === p2) {
    alert("Player names must be different");
    return;
  }
  
  try {
    // Create game document
    const game = await databases.createDocument(
      DATABASE_ID,
      COLLECTION_GAMES,
      ID.unique(),
      {
        player1: p1,
        player2: p2,
        p1Score: 0,
        p2Score: 0,
        turn: 1,
        status: 'active',
        createdAt: new Date().toISOString(),
        createdBy: loggedInUserId
      }
    );
    
    currentGameId = game.$id;
    playerIds = [p1, p2];
    
    gameState = {
      p1Score: 0,
      p2Score: 0,
      turn: 1,
      grid: [],
      history: [],
      paused: false
    };
    
    // Clear inputs
    player1Input.value = '';
    player2Input.value = '';
    
    // Show game page
    showPage('game-page');
    updateGameUI();
  } catch (error) {
    console.error('Game setup error:', error);
    alert('Could not create game. Make sure Appwrite is configured.');
  }
}

async function setupChatOnly() {
  try {
    // Get or create another user for chat
    const els = getGameElements();
    const setupChatInput = document.getElementById('chat-setup-input');
    
    if (!setupChatInput) {
      showPage('chat-page');
      loadChatMessages();
      return;
    }
    
    const otherUsername = setupChatInput.value.trim();
    if (!otherUsername) {
      alert("Enter another username to chat with");
      return;
    }
    
    if (otherUsername === loggedInUser) {
      alert("Enter a different username");
      return;
    }
    
    try {
      const results = await databases.listDocuments(
        DATABASE_ID,
        COLLECTION_USERS,
        [Query.equal('username', otherUsername)]
      );
      
      if (results.documents.length === 0) {
        // Create new user
        await databases.createDocument(
          DATABASE_ID,
          COLLECTION_USERS,
          ID.unique(),
          {
            username: otherUsername,
            createdAt: new Date().toISOString(),
            lastActive: new Date().toISOString()
          }
        );
      }
    } catch (err) {
      console.log("User creation/check error (non-critical):", err);
    }
    
    if (setupChatInput) setupChatInput.value = '';
    showPage('chat-page');
    loadChatMessages();
  } catch (error) {
    console.error('Chat setup error:', error);
    alert('Chat setup failed.');
  }
}

function updateGameUI() {
  const els = getGameElements();
  
  if (els.statusText) {
    const playerName = gameState.turn === 1 ? (playerIds[0] || 'Player 1') : (playerIds[1] || 'Player 2');
    els.statusText.textContent = `${playerName} ki turn`;
  }
  
  if (els.scoreboard) {
    els.scoreboard.innerHTML = `
      <div class="score-item">
        <div class="score-label">${playerIds[0] || 'Player 1'}</div>
        <div class="score-value">${gameState.p1Score || 0}</div>
      </div>
      <div class="score-item">
        <div class="score-label">${playerIds[1] || 'Player 2'}</div>
        <div class="score-value">${gameState.p2Score || 0}</div>
      </div>
    `;
  }
}

function checkLoggedInStatus() {
  const savedUser = localStorage.getItem('loggedInUser');
  const savedUserId = localStorage.getItem('loggedInUserId');
  
  if (savedUser && savedUserId) {
    loggedInUser = savedUser;
    loggedInUserId = savedUserId;
    return true;
  }
  return false;
}

// Auto-login if user exists in localStorage
document.addEventListener('DOMContentLoaded', () => {
  if (checkLoggedInStatus()) {
    showPage('setup-game-page');
  } else {
    showPage('login-page');
  }
});
