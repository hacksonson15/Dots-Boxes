// ============ GAME LOGIC & UTILITIES ============

// GAME STATE
const gameConfig = {
  gridSize: 4,
  colors: ['#3295ff', '#ff3eaa', '#00ff88', '#ffcc00'],
  selectedColor: 0,
  soundEnabled: false,
  animationSpeed: 0.3,
  difficultyLevel: 'normal'
};

// Get all necessary DOM elements - wrapped in a function to avoid early initialization
function getGameElements() {
  return {
    canvas: document.getElementById('game-canvas'),
    canvas3d: document.getElementById('canvas-3d'),
    homePage: document.getElementById('home-page'),
    loginPage: document.getElementById('login-page'),
    setupGamePage: document.getElementById('setup-game-page'),
    setupChatPage: document.getElementById('setup-chat-page'),
    gamePage: document.getElementById('game-page'),
    chatPage: document.getElementById('chat-page'),
    settingsPage: document.getElementById('settings-page'),
    statusText: document.getElementById('status-text'),
    scoreboard: document.getElementById('scoreboard'),
    gameContainer: document.getElementById('game-container'),
    restartIcon: document.getElementById('restart-icon'),
    pauseIcon: document.getElementById('pause-icon'),
    settingsIcon: document.getElementById('settings-icon'),
    chatInput: document.getElementById('chat-input'),
    chatMessages: document.getElementById('chat-messages'),
    homeBtn: document.getElementById('home-btn'),
    modalResetBtn: document.getElementById('modal-reset-btn'),
    usernameInput: document.getElementById('username-input'),
    player1Input: document.getElementById('player1-input'),
    player2Input: document.getElementById('player2-input')
  };
}

// Page visibility management
function showPage(pageId) {
  const els = getGameElements();
  
  // Hide all pages
  [els.homePage, els.loginPage, els.setupGamePage, els.setupChatPage, 
   els.gamePage, els.chatPage, els.settingsPage].forEach(el => {
    if (el) el.classList.add('hidden');
  });
  
  // Show selected page
  const page = document.getElementById(pageId);
  if (page) page.classList.remove('hidden');
}

// Color management
function setPlayerColor(colorIndex) {
  gameConfig.selectedColor = colorIndex;
  localStorage.setItem('playerColor', colorIndex);
  const els = getGameElements();
  if (els.canvas) {
    // Trigger redraw with new color
    updateGameCanvas();
  }
}

function getSoundState() {
  return gameConfig.soundEnabled;
}

function setSoundState(enabled) {
  gameConfig.soundEnabled = enabled;
  localStorage.setItem('soundEnabled', enabled);
}

function getAnimationSpeed() {
  return gameConfig.animationSpeed;
}

function setAnimationSpeed(speed) {
  gameConfig.animationSpeed = speed;
  localStorage.setItem('animationSpeed', speed);
}

function getDifficultyLevel() {
  return gameConfig.difficultyLevel;
}

function setDifficultyLevel(level) {
  gameConfig.difficultyLevel = level;
  localStorage.setItem('difficultyLevel', level);
}

// Load game settings from localStorage
function loadGameSettings() {
  const savedColor = localStorage.getItem('playerColor');
  const savedSound = localStorage.getItem('soundEnabled');
  const savedSpeed = localStorage.getItem('animationSpeed');
  const savedDifficulty = localStorage.getItem('difficultyLevel');
  
  if (savedColor !== null) gameConfig.selectedColor = parseInt(savedColor);
  if (savedSound !== null) gameConfig.soundEnabled = savedSound === 'true';
  if (savedSpeed !== null) gameConfig.animationSpeed = parseFloat(savedSpeed);
  if (savedDifficulty !== null) gameConfig.difficultyLevel = savedDifficulty;
}

// Update game canvas
function updateGameCanvas() {
  const els = getGameElements();
  if (!els.canvas || !els.canvas.getContext) return;
  
  const ctx = els.canvas.getContext('2d');
  const width = els.canvas.width;
  const height = els.canvas.height;
  
  // Clear canvas
  ctx.fillStyle = 'rgba(8, 11, 24, 0.8)';
  ctx.fillRect(0, 0, width, height);
  
  // Draw game grid (simplified)
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
  ctx.lineWidth = 1;
  
  const cellSize = width / gameConfig.gridSize;
  for (let i = 0; i <= gameConfig.gridSize; i++) {
    // Horizontal lines
    ctx.beginPath();
    ctx.moveTo(0, i * cellSize);
    ctx.lineTo(width, i * cellSize);
    ctx.stroke();
    
    // Vertical lines
    ctx.beginPath();
    ctx.moveTo(i * cellSize, 0);
    ctx.lineTo(i * cellSize, height);
    ctx.stroke();
  }
}

// Game restart handler
async function handleRestart() {
  if (!confirm('Game restart hogi — sure?')) return;
  
  const els = getGameElements();
  
  try {
    // Reset local game state
    gameState = {
      p1Score: 0,
      p2Score: 0,
      turn: 1,
      grid: [],
      history: [],
      paused: false
    };
    currentGameId = null;
    
    // Update UI
    if (els.statusText) els.statusText.textContent = 'Game ready! Player 1 ki turn...';
    if (els.scoreboard) els.scoreboard.innerHTML = '<div class="score-item"><div class="score-label">Player 1</div><div class="score-value">0</div></div><div class="score-item"><div class="score-label">Player 2</div><div class="score-value">0</div></div>';
    
    // Redraw canvas
    updateGameCanvas();
  } catch (error) {
    console.error('Restart error:', error);
    alert('Game restart nahi ho saki.');
  }
}

// Pause/Resume
let gamePaused = false;
function togglePause() {
  gamePaused = !gamePaused;
  const els = getGameElements();
  if (els.statusText) {
    els.statusText.textContent = gamePaused ? '⏸️ PAUSED' : 'Playing...';
  }
}

// Logout handler
function handleLogout() {
  if (!confirm('Logout? Phir se login karna hoga.')) return;
  
  loggedInUser = null;
  loggedInUserId = null;
  playerIds = [];
  gameState = null;
  currentGameId = null;
  
  localStorage.removeItem('loggedInUser');
  showPage('login-page');
}

// Load settings from localStorage on page load
window.addEventListener('DOMContentLoaded', loadGameSettings);
