// ============ CHAT FUNCTIONS ============

const GIPHY_API_KEY = "FN9GOy48CMyQvN0MmunG1ATaWyLDsqQA";
let pickerOpen = false;
let currentPickerTab = "emoji";
let gifSearchTimeout = null;
let editingMessageId = null;
let activeReplyTo = null;

function getChatElements() {
  return {
    chatInput: document.getElementById('chat-input'),
    chatMessages: document.getElementById('chat-messages'),
    chatSendBtn: document.getElementById('chat-send-btn'),
    chatPickerPanel: document.getElementById('chat-picker-panel'),
    gifSearchInput: document.getElementById('gif-search-input'),
    gifGrid: document.getElementById('gif-grid'),
    contentEmoji: document.getElementById('content-emoji'),
    contentGif: document.getElementById('content-gif'),
    tabEmoji: document.getElementById('tab-emoji'),
    tabGif: document.getElementById('tab-gif'),
    chatEmojiOpenBtn: document.querySelector('.chat-emoji-open-btn')
  };
}

async function loadChatMessages() {
  const els = getChatElements();
  if (!els.chatMessages) return;
  
  try {
    const response = await databases.listDocuments(
      DATABASE_ID,
      COLLECTION_MESSAGES,
      [Query.orderAsc('createdAt'), Query.limit(30)]
    );
    
    els.chatMessages.innerHTML = '';
    response.documents.forEach(doc => {
      addChatMessageDoc(doc, loggedInUser === doc.sender ? 'mine' : 'theirs');
    });
    
    // Auto-scroll to bottom
    els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
  } catch (error) {
    console.error('Error loading messages:', error);
  }
}

function addChatMessageDoc(doc, type) {
  const els = getChatElements();
  if (!els.chatMessages) return;
  
  const msgEl = document.createElement('div');
  msgEl.id = `msg-${doc.$id}`;
  msgEl.className = `chat-message ${type}`;
  
  const avatar = document.createElement('div');
  avatar.className = 'chat-avatar';
  avatar.style.background = gameConfig.colors[playerIds.indexOf(doc.$id) % gameConfig.colors.length];
  avatar.textContent = doc.sender[0].toUpperCase();
  
  const content = document.createElement('div');
  content.className = 'msg-content';
  
  const sender = document.createElement('div');
  sender.className = 'msg-sender';
  sender.textContent = doc.sender;
  
  const text = document.createElement('div');
  text.className = 'msg-text';
  
  // Handle GIF messages
  if (doc.text.startsWith('[GIF]')) {
    const gifUrl = doc.text.substring(5);
    const gifImg = document.createElement('img');
    gifImg.src = gifUrl;
    gifImg.style.cssText = 'max-width:100%;border-radius:8px;margin:6px 0;';
    gifImg.alt = 'GIF message';
    text.appendChild(gifImg);
  } else {
    text.textContent = doc.text;
  }
  
  const time = document.createElement('div');
  time.className = 'msg-time';
  const msgTime = new Date(doc.createdAt);
  time.textContent = msgTime.toLocaleTimeString('en-PK', { hour: '2-digit', minute: '2-digit' });
  
  if (doc.isEdited) {
    const edited = document.createElement('span');
    edited.textContent = ' (edited)';
    edited.style.fontSize = '10px';
    edited.style.opacity = '0.6';
    time.appendChild(edited);
  }
  
  // Add reply preview if replying to another message
  if (doc.replyTo) {
    const replyData = JSON.parse(doc.replyTo);
    const replyEl = document.createElement('div');
    replyEl.className = 'reply-preview';
    replyEl.style.cssText = 'background:rgba(255,255,255,.08);padding:6px 8px;border-left:3px solid #3295ff;border-radius:4px;margin-bottom:6px;font-size:12px;color:#9aa8c7;';
    replyEl.textContent = `↳ ${replyData.sender}: ${replyData.text.substring(0, 40)}...`;
    content.appendChild(replyEl);
  }
  
  content.appendChild(sender);
  content.appendChild(text);
  content.appendChild(time);
  
  // Add action buttons
  const actions = document.createElement('div');
  actions.style.cssText = 'display:flex;gap:4px;margin-top:4px;';
  
  if (type === 'mine') {
    const editBtn = document.createElement('button');
    editBtn.textContent = '✏️';
    editBtn.style.cssText = 'width:24px;height:24px;padding:0;font-size:12px;';
    editBtn.onclick = () => editChatMessage(doc.$id, doc.text);
    
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = '🗑️';
    deleteBtn.style.cssText = 'width:24px;height:24px;padding:0;font-size:12px;';
    deleteBtn.onclick = () => deleteChatMessage(doc.$id);
    
    actions.appendChild(editBtn);
    actions.appendChild(deleteBtn);
  }
  
  const replyBtn = document.createElement('button');
  replyBtn.textContent = '↩️';
  replyBtn.style.cssText = 'width:24px;height:24px;padding:0;font-size:12px;';
  replyBtn.onclick = () => setReply(doc.$id, doc.sender, doc.text);
  actions.appendChild(replyBtn);
  
  msgEl.appendChild(avatar);
  msgEl.appendChild(content);
  msgEl.appendChild(actions);
  
  els.chatMessages.appendChild(msgEl);
  els.chatMessages.scrollTop = els.chatMessages.scrollHeight;
}

function setReply(msgId, sender, text) {
  const els = getChatElements();
  activeReplyTo = { msgId, sender, text };
  
  // Show reply preview in input area
  let replyPreview = document.getElementById('reply-preview');
  if (!replyPreview) {
    replyPreview = document.createElement('div');
    replyPreview.id = 'reply-preview';
    replyPreview.style.cssText = 'background:rgba(50,149,255,.15);padding:8px;border-left:4px solid #3295ff;border-radius:4px;margin-bottom:8px;font-size:13px;display:flex;justify-content:space-between;align-items:center;';
    els.chatInput?.parentElement?.insertBefore(replyPreview, els.chatInput?.parentElement?.firstChild);
  }
  replyPreview.innerHTML = `↳ ${sender}: <strong>${text.substring(0, 50)}...</strong>`;
  
  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = '✕';
  cancelBtn.style.cssText = 'width:24px;height:24px;padding:0;';
  cancelBtn.onclick = cancelReply;
  replyPreview.appendChild(cancelBtn);
}

function cancelReply() {
  activeReplyTo = null;
  const replyPreview = document.getElementById('reply-preview');
  if (replyPreview) replyPreview.remove();
}

function editChatMessage(msgId, currentText) {
  editingMessageId = msgId;
  const els = getChatElements();
  if (els.chatInput) {
    els.chatInput.innerText = currentText;
    els.chatInput.focus();
  }
}

async function deleteChatMessage(msgId) {
  if (!confirm("Delete this message?")) return;
  try {
    await databases.deleteDocument(DATABASE_ID, COLLECTION_MESSAGES, msgId);
    const targetEl = document.getElementById(`msg-${msgId}`);
    if (targetEl) targetEl.remove();
  } catch (err) {
    alert("Could not delete message.");
  }
}

async function clearAllChats() {
  if (!confirm("Sari chats clear ho jayengi dono users ki — sure ho?")) return;
  
  const els = getChatElements();
  if (els.chatMessages) els.chatMessages.innerHTML = "";
  
  try {
    let keepGoing = true;
    while (keepGoing) {
      const res = await databases.listDocuments(
        DATABASE_ID,
        COLLECTION_MESSAGES,
        [Query.limit(100)]
      );
      if (res.documents.length === 0) break;
      
      await Promise.all(
        res.documents.map(doc =>
          databases.deleteDocument(DATABASE_ID, COLLECTION_MESSAGES, doc.$id)
        )
      );
      
      if (res.documents.length < 100) keepGoing = false;
    }
  } catch (err) {
    console.error("Clear error:", err);
  }
}

function trimChatToMax30() {
  const els = getChatElements();
  if (!els.chatMessages) return;
  
  const realMessages = Array.from(els.chatMessages.querySelectorAll(".chat-message:not(.status)"));
  while (realMessages.length > 30) {
    const oldestMsg = realMessages.shift();
    oldestMsg.remove();
  }
}

async function sendChatMessage() {
  const els = getChatElements();
  const message = els.chatInput?.innerText.trim();
  if (!message) return;
  
  if (editingMessageId) {
    const msgId = editingMessageId;
    cancelReply();
    try {
      const updatedDoc = await databases.updateDocument(
        DATABASE_ID,
        COLLECTION_MESSAGES,
        msgId,
        { text: message, isEdited: true }
      );
      updateChatMessageUI(updatedDoc);
    } catch (err) {
      alert("Failed to edit message.");
    }
    editingMessageId = null;
    if (els.chatInput) els.chatInput.innerText = '';
    return;
  }
  
  const payload = {
    sender: loggedInUser,
    text: message,
    createdAt: new Date().toISOString()
  };
  
  if (activeReplyTo) {
    payload.replyTo = JSON.stringify(activeReplyTo);
  }
  
  cancelReply();
  if (els.chatInput) els.chatInput.innerText = '';
  
  try {
    const newDoc = await databases.createDocument(
      DATABASE_ID,
      COLLECTION_MESSAGES,
      ID.unique(),
      payload
    );
    addChatMessageDoc(newDoc, "mine");
    trimChatToMax30();
  } catch (error) {
    console.error(error);
    alert("Failed to send message. Make sure Appwrite attributes are configured.");
  }
}

function updateChatMessageUI(doc) {
  const el = document.getElementById(`msg-${doc.$id}`);
  if (el) {
    const textEl = el.querySelector('.msg-text');
    if (textEl) {
      textEl.textContent = doc.text;
    }
  }
}

/* ==================== EMOJI / GIF PICKER ==================== */

function populateEmojiTab() {
  const els = getChatElements();
  if (!els.contentEmoji || els.contentEmoji.children.length > 0) return;
  
  ALL_EMOJIS.forEach(emoji => {
    const btn = document.createElement("span");
    btn.className = "panel-emoji-btn";
    btn.textContent = emoji;
    btn.onclick = () => {
      const input = els.chatInput;
      if (!input) return;
      input.focus();
      const sel = window.getSelection();
      if (sel && sel.rangeCount) {
        const range = sel.getRangeAt(0);
        range.deleteContents();
        range.insertNode(document.createTextNode(emoji));
        range.collapse(false);
        sel.removeAllRanges();
        sel.addRange(range);
      } else {
        input.innerText += emoji;
      }
      closePickerPanel();
    };
    els.contentEmoji?.appendChild(btn);
  });
}

function togglePickerPanel() {
  const els = getChatElements();
  pickerOpen = !pickerOpen;
  if (pickerOpen) {
    els.chatPickerPanel?.classList.remove("hidden");
    populateEmojiTab();
    if (currentPickerTab === "gif") loadTrendingGifs();
    if (els.chatEmojiOpenBtn) els.chatEmojiOpenBtn.style.color = "#3295ff";
  } else {
    closePickerPanel();
  }
}

function closePickerPanel() {
  const els = getChatElements();
  els.chatPickerPanel?.classList.add("hidden");
  pickerOpen = false;
  if (els.chatEmojiOpenBtn) els.chatEmojiOpenBtn.style.color = "#9aa8c7";
}

function switchPickerTab(tab) {
  const els = getChatElements();
  currentPickerTab = tab;
  
  els.tabEmoji?.classList.toggle("active", tab === "emoji");
  els.tabGif?.classList.toggle("active", tab === "gif");
  els.contentEmoji?.classList.toggle("active", tab === "emoji");
  els.contentGif?.classList.toggle("active", tab === "gif");
  
  if (tab === "gif") {
    const grid = els.gifGrid;
    if (grid?.querySelector(".gif-loading")) {
      loadTrendingGifs();
    }
  }
}

async function loadTrendingGifs() {
  const els = getChatElements();
  if (!els.gifGrid) return;
  
  els.gifGrid.innerHTML = `<div class="gif-loading">⏳ Trending load ho raha hai...</div>`;
  try {
    const res = await fetch(
      `https://api.giphy.com/v1/gifs/trending?api_key=${GIPHY_API_KEY}&limit=20&rating=pg`
    );
    const data = await res.json();
    renderGifs(data.data);
  } catch(e) {
    if (els.gifGrid) els.gifGrid.innerHTML = `<div class="gif-loading">⚠️ GIFs load nahi hue. Internet check karo.</div>`;
  }
}

async function searchGifs() {
  const els = getChatElements();
  const query = els.gifSearchInput?.value.trim();
  if (!query) { loadTrendingGifs(); return; }
  
  if (els.gifGrid) els.gifGrid.innerHTML = `<div class="gif-loading">🔍 "${query}" search ho raha hai...</div>`;
  
  try {
    const res = await fetch(
      `https://api.giphy.com/v1/gifs/search?api_key=${GIPHY_API_KEY}&q=${encodeURIComponent(query)}&limit=20&rating=pg`
    );
    const data = await res.json();
    renderGifs(data.data);
  } catch(e) {
    const els = getChatElements();
    if (els.gifGrid) els.gifGrid.innerHTML = `<div class="gif-loading">⚠️ Search fail ho gayi.</div>`;
  }
}

function renderGifs(gifs) {
  const els = getChatElements();
  if (!els.gifGrid) return;
  
  els.gifGrid.innerHTML = "";
  if (!gifs || gifs.length === 0) {
    els.gifGrid.innerHTML = `<div class="gif-loading">Koi GIF nahi mili 😕</div>`;
    return;
  }
  
  gifs.forEach(gif => {
    const previewUrl = gif.images.fixed_height_small.url;
    const originalUrl = gif.images.original.url;
    
    const item = document.createElement("div");
    item.className = "gif-item";
    item.style.cssText = "width:100%;height:100px;overflow:hidden;border-radius:8px;cursor:pointer;background:#0d1117;";
    
    const img = document.createElement("img");
    img.src = previewUrl;
    img.alt = gif.title || "GIF";
    img.loading = "lazy";
    img.style.cssText = "width:100%;height:100%;object-fit:cover;display:block;";
    
    item.appendChild(img);
    item.onclick = () => sendGifMessage(originalUrl, gif.title || "GIF");
    els.gifGrid.appendChild(item);
  });
}

async function sendGifMessage(gifUrl, gifTitle) {
  closePickerPanel();
  
  const payload = {
    sender: loggedInUser,
    text: `[GIF]${gifUrl}`,
    createdAt: new Date().toISOString()
  };
  
  if (activeReplyTo) {
    payload.replyTo = JSON.stringify(activeReplyTo);
    cancelReply();
  }
  
  try {
    const newDoc = await databases.createDocument(
      DATABASE_ID,
      COLLECTION_MESSAGES,
      ID.unique(),
      payload
    );
    addChatMessageDoc(newDoc, "mine");
    trimChatToMax30();
  } catch (error) {
    console.error(error);
    alert("GIF send nahi ho saka.");
  }
}

// Initialize GIF search event listeners
document.addEventListener("DOMContentLoaded", () => {
  const gifSearchInput = document.getElementById("gif-search-input");
  if (gifSearchInput) {
    gifSearchInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") { searchGifs(); return; }
      clearTimeout(gifSearchTimeout);
      gifSearchTimeout = setTimeout(searchGifs, 600);
    });
  }
});

// Close picker when clicking outside
document.addEventListener("click", (e) => {
  if (!pickerOpen) return;
  const els = getChatElements();
  if (!els.chatPickerPanel?.contains(e.target) && !els.chatEmojiOpenBtn?.contains(e.target)) {
    closePickerPanel();
  }
});
