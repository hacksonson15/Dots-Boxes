// ============ APPWRITE CONFIG & INIT ============
const client = new Appwrite.Client();
const databases = new Appwrite.Databases(client);
const ID = Appwrite.ID;
const Query = Appwrite.Query;

// UPDATE THESE VALUES TO CONNECT TO YOUR APPWRITE:
const APPWRITE_ENDPOINT = "https://fra.cloud.appwrite.io/v1";
const APPWRITE_PROJECT_ID = "67331d1800061e6af70e";
const DATABASE_ID = "6733221f000dd3c54ddb";
const COLLECTION_USERS = "6733222900159bd7fa17";
const COLLECTION_GAMES = "67332232002e098dd40e";
const COLLECTION_MESSAGES = "6733228300056798f0f9";

client
  .setEndpoint(APPWRITE_ENDPOINT)
  .setProject(APPWRITE_PROJECT_ID);

// EMOJIS ARRAY
const ALL_EMOJIS = [
  "😀","😃","😄","😁","😆","😅","🤣","😂","🙂","🙃","😉","😊","😇","🥰","😍","🤩","😘","😗","😚","😙","🥲","😋","😛","😜","🤪","😌","😔","😑","😐","😶","😏","😒","🙄","😬","🤥","😌","😔","😪","🤤","😴","😷","🤒","🤕","🤮","🤮","🤢","🤮","🤮","😵","🤯","🤠","🥳","😎","🤓","🧐","😕","😟","🙁","☹️","😮","😯","😲","😳","🥺","😦","😧","😨","😰","😥","😢","😭","😱","😖","😣","😞","😓","😩","😫","🥱","😤","😡","😠","🤬","😈","👿","💀","💔","🎃","👻","⚠️"
];

// Global state for users
let loggedInUser = null;
let loggedInUserId = null;
let playerIds = [];
let gameState = null;
let currentGameId = null;
