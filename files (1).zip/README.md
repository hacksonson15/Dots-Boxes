# Dots & Boxes 3D - Game & Chat Application

یہ ایک complete 2-player game اور chat application ہے جو Appwrite backend کے ساتھ کام کرتا ہے۔

## 📁 File Structure

```
project/
├── index.html              # Main single-page app (سب کچھ ایک ہی صفحے میں)
├── login.html              # Login/Signup page
├── game.html               # Game interface  
├── chat.html               # Chat interface
├── appwrite_config.js      # Appwrite configuration & initialization
├── game_logic.js           # Game logic & utilities
├── auth_functions.js       # Login & authentication functions
├── chat_functions.js       # Chat & messaging functions
├── styles.css              # Shared CSS styles
└── README.md              # یہ فائل
```

## 🚀 Installation & Setup

### Step 1: Appwrite Setup

1. Appwrite account بنائیں: https://appwrite.io
2. ایک نیا project بنائیں
3. ان collections بنائیں:

**Collection 1: USERS**
- Attributes:
  - `username` (String, Required)
  - `createdAt` (DateTime)
  - `lastActive` (DateTime)

**Collection 2: GAMES**
- Attributes:
  - `player1` (String)
  - `player2` (String)
  - `p1Score` (Integer)
  - `p2Score` (Integer)
  - `turn` (Integer)
  - `status` (String)
  - `createdAt` (DateTime)
  - `createdBy` (String)

**Collection 3: MESSAGES**
- Attributes:
  - `sender` (String)
  - `text` (String)
  - `createdAt` (DateTime)
  - `isEdited` (Boolean)
  - `replyTo` (String)

### Step 2: Configuration

`appwrite_config.js` میں اپنی Appwrite details ڈالیں:

```javascript
const APPWRITE_ENDPOINT = "https://your-endpoint.appwrite.io/v1";
const APPWRITE_PROJECT_ID = "your_project_id";
const DATABASE_ID = "your_database_id";
const COLLECTION_USERS = "your_users_collection_id";
const COLLECTION_GAMES = "your_games_collection_id";
const COLLECTION_MESSAGES = "your_messages_collection_id";
```

### Step 3: Deploy

تمام files کو اپنے server/hosting پر upload کریں:
- **Best Option**: Simple HTTP server استعمال کریں
```bash
python -m http.server 8000
# یا
python3 -m http.server 8000
```

Browser میں `http://localhost:8000` کھولیں۔

## 📖 Usage

### Single Page Mode (index.html)
تمام functionality ایک ہی page میں، بغیر reload کے:
```
localhost:8000/index.html
```

### Multi-Page Mode (Separate files)
- **Login**: `login.html` - صرف login/signup
- **Game**: `game.html` - Game اور settings
- **Chat**: `chat.html` - Chat interface

## ✨ Features

### 🎮 Game Features
- 2-Player Dots & Boxes game
- Real-time score tracking
- Game pause/restart
- Settings (sound, animation speed, difficulty)
- Player color customization
- Game history in Appwrite

### 💬 Chat Features
- Real-time messaging
- Emoji picker (تمام مشہور emojis)
- GIF search & send (Giphy API)
- Message editing
- Message deletion
- Reply to messages
- Message history (last 30 messages on display)
- Clear all chats option

### 👤 User Features
- Simple login/signup
- User profiles in Appwrite
- Persistent login (localStorage)
- Auto-login on page refresh

## 🎯 Key Technical Features

### Performance Optimizations
- ✅ Lazy loading emojis (only load on first open)
- ✅ Lazy loading GIFs (only when needed)
- ✅ Canvas rendering کے لیے `transform: translateZ(0)`
- ✅ Backdrop blur کے لیے will-change optimization
- ✅ Radial gradients کو pseudo-element میں (no repaints)
- ✅ Message display max 30 (no pagination overhead)
- ✅ Parallel API calls (Promise.all) for clearing chats

### Data Management
- User data → Appwrite Users collection
- Game progress → Appwrite Games collection
- Messages → Appwrite Messages collection
- Settings → localStorage (fast access)

### Security Considerations
- ✅ Email/password نہیں (simple username login)
- ✅ No sensitive data in localStorage (صرف username & user ID)
- ✅ Appwrite rules کو properly configure کریں

## 🔧 Customization

### Colors Theme
`styles.css` میں CSS variables change کریں:
```css
:root {
  --bg:#080b18;           /* Background color */
  --accent:#3295ff;       /* Primary accent */
  --p2-color:#ff3eaa;     /* Secondary color */
  --text:#f8fafc;         /* Text color */
}
```

### Grid Size (Game)
`game_logic.js` میں:
```javascript
gameConfig.gridSize = 4; // 4x4 grid (change to 5 for 5x5, etc)
```

### Player Colors
`appwrite_config.js` میں:
```javascript
colors: ['#3295ff', '#ff3eaa', '#00ff88', '#ffcc00']
```

## 🐛 Troubleshooting

### "Appwrite connection failed"
- ✅ Appwrite endpoint, project ID, اور database ID چیک کریں
- ✅ Collections attributes صحیح ہوں
- ✅ Appwrite service running ہے

### "Login not working"
- ✅ COLLECTION_USERS صحیح ہے
- ✅ `username` attribute موجود ہے
- ✅ Browser console میں errors چیک کریں

### "Chat messages not loading"
- ✅ COLLECTION_MESSAGES موجود ہے
- ✅ Appwrite API key/permissions صحیح ہیں
- ✅ Network tab میں API calls چیک کریں

### "Emojis/GIFs not showing"
- ✅ Browser CDN access کر سکتا ہے
- ✅ JavaScript errors نہیں ہیں
- ✅ GIF search کے لیے internet connection ہے

## 📱 Browser Support

- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (iOS/macOS)
- ✅ Mobile browsers

## 🎨 UI Features

### Responsive Design
- Mobile-first approach
- Max width: 700px (chat), 680px (game)
- Touch-friendly buttons
- Overflow scrolling

### Animations
- Smooth page transitions (cardIn animation)
- Button press animations
- Emoji pop animations
- Loading spinners

### Accessibility
- Semantic HTML
- Keyboard navigation (Enter to send)
- Color contrast compliant
- Touch-action: none (prevents double-tap zoom on game)

## 📊 Performance Tips

1. **Database Optimization**:
   - Messages cleanup (auto-trim to 30)
   - Old messages stay in DB (not deleted)
   - Use indexing on commonly queried fields

2. **Frontend Optimization**:
   - Browser caching for static files
   - Service Worker استعمال کریں (optional)
   - LocalStorage for settings

3. **Network Optimization**:
   - Chat auto-refresh هر 2 سیکنڈ
   - Batch API calls جہاں ممکن ہو
   - Lazy load emoji/GIF panels

## 📞 Support

Issues کے لیے:
1. Browser console check کریں (F12)
2. Network tab میں API calls دیکھیں
3. Appwrite logs دیکھیں
4. Files درست جگہ پر ہیں check کریں

## 🎓 Architecture

### Data Flow
```
User Input 
  ↓
auth_functions.js / game_logic.js / chat_functions.js
  ↓
appwrite_config.js (API calls)
  ↓
Appwrite Backend
  ↓
localStorage (settings cache)
```

### Page Navigation
```
login.html → game.html ↔ chat.html
     ↓
localStorage (persist login)
```

## ✅ Checklist Before Going Live

- [ ] Appwrite endpoint configured
- [ ] All collection IDs added
- [ ] Security rules set in Appwrite
- [ ] HTTPS enabled (if needed)
- [ ] CDN links working (Appwrite, Giphy)
- [ ] All files in same directory
- [ ] Database backups configured
- [ ] Error logging enabled
- [ ] Mobile testing done
- [ ] Performance tested (Lighthouse)

## 📝 Version

**Version 1.0** - Complete split architecture with separate HTML files for login, game, and chat.

---

**Made with ❤️ for multiplayer gaming**
